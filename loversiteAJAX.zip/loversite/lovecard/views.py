from django.shortcuts import render
from django.shortcuts import HttpResponse, HttpResponseRedirect
from django.template import loader
from .models import Card
import re
from django.http import HttpResponseRedirect


# Create your views here.

def index(request):
    template = loader.get_template('lovecard/rotating-card.html')
    cards_temp = Card.objects.all()
    return HttpResponse(template.render({'cards': cards_temp}, request))

def like(request):
    card_id = None
    if request.method == 'GET':
        card_id = request.GET['card_id']
        print(card_id)

        if card_id:
            card = Card.objects.get(id=(int(card_id)))
            if card:
                likes = card.likes + 1
                card.likes = likes
                card.save()

    return HttpResponse(likes)
    #return HttpResponseRedirect ("/like/")
