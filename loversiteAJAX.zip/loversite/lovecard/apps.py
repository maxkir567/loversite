from django.apps import AppConfig


class LovecardConfig(AppConfig):
    name = 'lovecard'
